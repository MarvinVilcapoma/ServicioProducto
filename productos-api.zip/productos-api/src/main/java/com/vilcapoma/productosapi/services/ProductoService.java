package com.vilcapoma.productosapi.services;

import java.util.List;

import com.vilcapoma.productosapi.entities.Producto;

public interface ProductoService {

	public List<Producto> findAll();
	
	public Producto findById(Long id);
	
	public void save(Producto producto);
	
	public void deleteById(Long id);
	
} 

