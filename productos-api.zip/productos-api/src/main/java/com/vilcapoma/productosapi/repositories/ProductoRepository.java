package com.vilcapoma.productosapi.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.vilcapoma.productosapi.entities.Producto;

public interface ProductoRepository extends CrudRepository<Producto, Long> {

	@Override
	List<Producto> findAll();
	
}
